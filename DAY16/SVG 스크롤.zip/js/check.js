
$(function() {

    // 스크롤 애니메이션 시작!
    $('.svg, .svg100').scrolla({
        mobile: true,
        once: false,
    })


})